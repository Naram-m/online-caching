import copy
import numpy as np
import cvxpy as cp
from optimistic_expert_1 import OptimisticExpert1

from robust_expert import RobustExpert


class OFTRLExpertsAgent():
    def __init__(self, l, locations, caches, files, max_cache_size):
        self.l = l
        self.files = files
        self.caches = caches
        self.locations = locations
        self.w = cp.Variable(2, nonneg=True)
        self.acc_grads = np.zeros(2)

        self.max_cache_size = max_cache_size
        self.standard_constraints = []
        self.actions = []
        self.grads = []
        self.high_level_grads = []
        self.acc_sigma = 0
        self.acc_sigma_action = 0
        self.sigmas = []
        ##############
        self.etas = []
        self.acc_grad_square = 0
        self.R = 1  # an upper bound on the l2 norm of x (20 Jan: not diameter?)
        ####################################### Constraints ###################################
        # For w:
        self.standard_constraints.extend([cp.sum(self.w) == 1])

        self.non_projected_sol_parameter = cp.Parameter(2, nonneg=True)
        self.objective = cp.Minimize(cp.sum_squares(self.w - self.non_projected_sol_parameter))
        self.prob = cp.Problem(self.objective, self.standard_constraints)

        self.oe_1 = OptimisticExpert1(l, locations, caches, files, max_cache_size, is_per=True, per = 1)
        self.re = RobustExpert(l, locations, caches, files, max_cache_size)

    def calc_sigma(self, pred):
        if not self.sigmas:  # no grads yet
            self.etas.append(1)  # for t=0
            self.sigmas.append(1 / self.etas[-1])  # from McMahan \sigma_0  = 1 / \eta_0
        else:
            self.acc_grad_square += np.linalg.norm(self.high_level_grads[-1] - pred, 2) ** 2
            self.etas.append(
                np.sqrt(2) * self.R / np.sqrt(self.acc_grad_square))  # this will be the second eta, after 0
            self.sigmas.append(1 / self.etas[-1] - 1 / self.etas[-2])

    def step(self, grad):
        rea = self.re.step(grad)
        oea_1 = self.oe_1.step(grad)

        if not self.high_level_grads:
            pred = np.array([0, 0])
        else:
            pred = self.high_level_grads[-1]

        if not self.actions:  # first action, minimize r_0, returning 0 because it assumed to be ||x||
            ww = np.array([0.5, 0.5])
        else:
            # 1- calculating y, all involved params should be ready.
            if self.acc_sigma > 0:
                # padded_pred = np.pad(pred, (0, self.files * self.caches), 'constant')
                # padded_acc_grad = np.pad(self.acc_grads, (0, self.files * self.caches), 'constant')
                # yy = (self.acc_sigma_action + (padded_acc_grad + padded_pred)) / self.acc_sigma  # verified
                ww = (self.acc_sigma_action + (self.acc_grads + pred)) / self.acc_sigma

            else:  # below is still not a parameter (perfect prediction case)
                a = self.acc_grads + pred
                # objective = cp.Maximize(a @ self.x)
                objective = cp.Maximize(a @ self.w)

                prob = cp.Problem(objective, self.standard_constraints)
                result = prob.solve(warm_start=True, solver='ECOS')

        # Projection
        if self.acc_sigma > 0 or not self.actions:
            # objective = cp.Minimize(cp.sum_squares(self.x - yy))
            # prob = cp.Problem(objective, self.standard_constraints)
            self.non_projected_sol_parameter.value = ww
            # numerical stability
            if np.any(ww[ww >= 1e6]):
                print("     !!! ops")
                ww[ww >= 1e6] = 1e6
            result = self.prob.solve(warm_start=True, solver='ECOS')
        if self.prob.value == np.inf or np.linalg.norm(self.w.value) >= 100:
            print("     !!! Ops")
            self.w.value = np.array([0.5, 0.5])
        self.actions.append(self.w.value)

        # 2 - preparing params for next round
        self.high_level_grads.append(np.array([np.dot(grad, rea), np.dot(grad, oea_1)]))
        self.acc_grads += self.high_level_grads[-1]
        self.calc_sigma(pred)
        self.acc_sigma += self.sigmas[-1]

        self.acc_sigma_action += (self.sigmas[-1] * self.actions[-1])

        return self.w.value[0] * rea + self.w.value[1] * oea_1
