import copy

import numpy as np
import cvxpy as cp
from collections import defaultdict
import matplotlib.pyplot as plt
# from data_interface import DataInterface


# noinspection DuplicatedCode
class CN():
    def __init__(self, num_constraints, utils, l, seed=412, locations=4, caches=3, files=100, max_cache_size=10):
        self.max_cache_size=max_cache_size
        self.locations = locations
        self.caches = caches  # +1 for the root
        self.files = files
        self.utils = utils
        self.l = l

        np.random.seed(seed)
        self.num_constraints = num_constraints
        self.dim = (files * caches) + (files * locations * caches)
        self.grad = 0
        self.const_grad = defaultdict()

        self.func_grads_history = {}
        self.consts_grads_history = {}
        self.call_count_adv = 0
        # self.di = DataInterface()
        self.trace = np.load("./ml_trace_10k.npy")
        self.ind = -1

    def generate_loss_function_wutils(self):  # this is generating r
        self.ind += 1
        r = [np.zeros(self.locations) for i in range(self.files)]
        #for location in range(self.locations):
        location = np.random.choice(range(self.locations))
        # requested_id = self.di.tr_sample()
        requested_id = self.trace[self.ind]
        r[requested_id][location] = 1
        # indent end

        r = np.concatenate(r).ravel() # comment this before printing to help visualize each file
        extended_r = np.repeat(r, self.caches)
        coeff = self.utils * extended_r
        self.grad = coeff
        return [coeff, 0]  # recall that r is indexed with n and then i


    def generate_loss_function_gradient(self, linear=True):
        return self.grad

    def generate_constraints(self):
        consts = defaultdict()  # Dictionary from each constraints to a list of grad, intercept
        rv = np.random.rand(self.caches)
        #bt = np.random.normal(0.5,0.05) * (self.caches * self.max_cache_size)  # heuristic: mony to store x files?
        bt = np.random.normal(0.5, 0.05) * 10 # enough for 3 files
        populated_const_grad = np.tile(rv, (1, self.files))[0]
        consts[0] = [populated_const_grad, bt]
        self.const_grad[0] = consts[0]
        return consts  # a defaultdict form const idx to a list l, l[0] cof vector, l[1] budget

    def generate_constraints_gradients(self):
        temp_dict = {}
        for k, v in self.const_grad.items():
            temp_dict[k] = v[0]
        return temp_dict

    # noinspection PyTypeChecker
    def get_best_hindsight(self, T, seed=412):
        np.random.seed(seed)
        y = cp.Variable(self.files * self.caches)                   # this is indexed as n,j
        z = cp.Variable(self.files * self.locations * self.caches)  # this is indexed as n, i, j
        constraints=[]

        # y set constraints
        y_consts_mat = []
        constraints.extend([y >= 0, y <= 1])
        for cache_idx in range(self.caches):
            const_coeff = np.zeros(self.files * self.caches)
            const_coeff[cache_idx::self.caches]=1
            '''below print for verification. this is the coeff vector of the constraints: 
            each vector (loop iteratoin) is for a cache the 1's corresponds to the elements that will be summed 
            from y_nj for that j'''
            #print(const_coeff)
            y_consts_mat.append(copy.deepcopy(const_coeff))
        y_consts_mat = np.array([np.array(constraint) for constraint in y_consts_mat])
        constraints.extend([y_consts_mat @ y <= self.max_cache_size]) # we can later customize / replace C

        # z set constraints
        constraints.extend([z >= 0, z <= 1])
        z_consts_mat = []
        for ni in range(self.files*self.locations):
            start = ni*(self.caches)
            end = (ni+1)*(self.caches)
            const_coeff = np.zeros(self.files * self.locations * self.caches)
            const_coeff[start : end] = 1
            '''below print for verification. this is the coeff vector of the constraints: 
            each vector (loop iteratoin) is for a fixed n,i choices. The 1's corresponds to the elements that will be summed 
            from z_ni, which is all j's'''
            z_consts_mat.append(copy.deepcopy(const_coeff))
        z_consts_mat = np.array([np.array(constraint) for constraint in z_consts_mat])
        constraints.extend([z_consts_mat @ z <= 1]) # we can later customize C

        # problem constraints
        self.fl = self.l.flatten()
        self.extended_fl = np.concatenate([self.fl for i in range(self.files)]).ravel()
        sl = []
        for p in range(self.files):
            start = self.caches * p
            end = self.caches * (p + 1)
            for pp in range(self.locations):
                sl.append(y[start:end])
        y_comp = cp.hstack(sl)
        constraints.extend([z <= cp.multiply(y_comp, self.extended_fl)])


        exp = 0
        #########################################
        consts = defaultdict()
        # rv = np.random.rand(self.caches)
        rv = np.array([1, 1, 1])
        # single_bt = np.random.normal(0.35, 0.05) * 10 # enough for 3 files
        single_bt = 3.5 # enough for 3 files np.random.rand(self.caches)

        populated_const_grad = np.tile(rv, (1, self.files))[0]
        consts[0] = [populated_const_grad, single_bt]
        bc = [consts[0][0] @ y <= consts[0][1]]
        constraints.extend(bc)
        #########################################

        for i in range(1, T):
            dumm1 = np.random.rand(self.files * self.locations * self.caches)  # to simulate prediction sampling

            np.random.random(1)
            random_file = np.random.randint(low=0, high=456)
            random_location = np.random.randint(low=0, high=4)

            r = self.generate_loss_function_wutils()[0]

            #######################################
            # consts = self.generate_constraints()
            # bc = [consts[0][0] @ y <= consts[0][1]]
            # constraints.extend(bc)
            #######################################
            rv_dum = np.random.rand(self.caches)
            bt_dum = np.random.normal(0.5, 0.05) * 10  # enough for 3 files

            self.func_grads_history[i] = r
            self.consts_grads_history[i] = consts  #this is not grad history? it is actually the full constraints
            exp += r @ z

        objective = cp.Maximize(exp)
        prob = cp.Problem(objective, constraints)
        result = prob.solve()

        return z.value, y.value, self.func_grads_history, self.consts_grads_history

