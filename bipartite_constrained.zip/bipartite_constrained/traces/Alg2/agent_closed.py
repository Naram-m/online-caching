import numpy as np
from collections import defaultdict
import cvxpy as cp
import copy


class Agent():

    def __init__(self, dim, consts_num, l, locations, caches, files, max_cache_size):
        self.accumelated_lambdat_st = 0
        self.max_cache_size = max_cache_size
        self.accumelated_stxt = 0
        self.accumelated_sigmas = 0

        self.beta = 1 / 2
        self.consts_num = consts_num
        self.dim = dim  # dimension of the action
        self.actions = defaultdict(int)  # from time_step -> action vector

        self.sigmas = defaultdict(int)
        #self.const_sigma = np.sqrt(2 * caches * self.max_cache_size + 2)
        self.const_sigma = np.sqrt(2) / np.sqrt(2 * caches * self.max_cache_size + 2)



        self.funcs = defaultdict(int)
        self.consts = defaultdict(dict)

        self.funcs_grads = defaultdict(int)  # time_step -> vector of length dim
        self.constraints_grads = defaultdict(dict)  # list of size (#constraints), each element is a dict:

        self.funcs_preds = defaultdict(int)
        self.consts_preds = defaultdict(dict)

        self.funcs_preds_grads = defaultdict(int)  # time_step -> vector of length dim
        self.consts_preds_grads = defaultdict(dict)  # list of size (#constraints), each element is a dict:

        self.duals = defaultdict(defaultdict)
        for i in range(consts_num):
            self.duals[1][i] = 0

        self.acc_grad = defaultdict()
        for i in range(self.consts_num):
            self.acc_grad[i] = 0
        #######################
        self.acc_func_grad = 0
        self.acc_diff_norm = 0
        ########################
        self.l = l
        self.files = files
        self.caches = caches
        self.locations = locations
        self.z_dim = self.files * self.locations * self.caches
        self.y_dim = self.files * self.caches
        self.z = cp.Variable(self.z_dim)
        self.y = cp.Variable(self.y_dim)
        self.x = cp.hstack([self.z, self.y])  # ! overwriting
        self.standard_constraints = []

        # For y:
        self.standard_constraints.extend([self.y >= 0, self.y <= 1])
        y_consts_mat = []
        for cache_idx in range(self.caches):
            const_coeff = np.zeros(self.files * self.caches)
            const_coeff[cache_idx::self.caches] = 1
            y_consts_mat.append(copy.deepcopy(const_coeff))
        y_consts_mat = np.array([np.array(constraint) for constraint in y_consts_mat])
        self.standard_constraints.extend(
            [y_consts_mat @ self.y <= self.max_cache_size])  # we can later customize / replace C

        # For z:
        self.standard_constraints.extend([self.z >= 0, self.z <= 1])
        z_consts_mat = []
        for ni in range(self.files * self.locations):
            start = ni * (self.caches)
            end = (ni + 1) * (self.caches)
            const_coeff = np.zeros(self.files * self.locations * self.caches)
            const_coeff[start: end] = 1
            z_consts_mat.append(copy.deepcopy(const_coeff))
        z_consts_mat = np.array([np.array(constraint) for constraint in z_consts_mat])
        self.standard_constraints.extend([z_consts_mat @ self.z <= 1])

        # From the problem
        self.fl = self.l.flatten()
        self.extended_fl = np.concatenate([self.fl for i in range(self.files)]).ravel()
        sl = []
        for p in range(self.files):
            start = self.caches * p
            end = self.caches * (p + 1)
            for pp in range(self.locations):
                sl.append(self.y[start:end])
        y_comp = cp.hstack(sl)
        self.standard_constraints.extend([self.z <= cp.multiply(y_comp, self.extended_fl)])


        self.non_projected_sol_parameter = cp.Parameter(self.z_dim + self.y_dim)
        self.objective = cp.Minimize(cp.sum_squares(self.x - self.non_projected_sol_parameter))
        self.prob = cp.Problem(self.objective, self.standard_constraints)



    ######################################Function#####################################

    def set_func(self, f, time_step, linear=False, quad=False, generic=False):
        if linear:  # f will contain two values only, the slop f[0] and intersept f[1]
            self.funcs[time_step] = [f[0], f[1]]  # if linear, this is how the nature will set the functoin

    def set_func_grad(self, f_prime, time_step, linear=True):
        if linear:  # f_prime will be the gradient
            self.funcs_grads[time_step] = f_prime

    def get_func_grad(self, time_step, action=-1):
        grad_func = self.funcs_grads[time_step]
        return grad_func

        ######################################Constraints#####################################

    def set_constraints(self, g, time_step, linear=True, quad=False, generic=False):  # !: g is a list
        for k, v in g.items():
            if linear:
                self.consts[time_step][k] = v  # v is a list, v[0] is vector, v[1] is a number

    def set_constraints_grad(self, g_primes, time_step, linear=True):
        for k, v in g_primes.items():
            if linear:
                self.constraints_grads[time_step][k] = v  # v is the vector, directly

    def get_constraints_grad(self, time_step, const_index, action):
        grad_func = self.constraints_grads[time_step][const_index]
        # in general, you should return the grad_func[index of action in the domain grid], below for linea, any index is the same
        return grad_func

    ###################################### Function Predictions #####################################

    def set_funcs_preds(self, fp, time_step, linear=False, quad=False, generic=False):
        if linear:  # f will contain two values only, the gradient f[0] and intersept f[1]
            self.funcs_preds[time_step] = [fp[0], fp[1]]  # if linear, this is how the nature will set the functoin

    "This function should be called by the environment when it announces its function"

    def set_funcs_preds_grads(self, f_prime_p, time_step, linear=False, quad=False, generic=False):
        if linear:  # f will contain only one value, the  (gradient)
            self.funcs_preds_grads[time_step] = f_prime_p

    def get_funcs_preds_grads(self, time_step, action=-1):
        grad_func = self.funcs_preds_grads[time_step]
        return grad_func

    ######################################Constraints Predictions#####################################

    def set_consts_preds(self, gp, time_step, linear=True):
        for k, v in gp.items():
            if linear:
                self.consts_preds[time_step][k] = v  # [v[0], v[1]]

    def set_consts_preds_grads(self, g_prime_p, time_step, linear=True):
        for k, v in g_prime_p.items():
            if linear:
                self.consts_preds_grads[time_step][k] = v

    def get_consts_preds_grads(self, fp, time_step, const_index):
        grad_func = self.consts_preds_grads[time_step][const_index]
        return grad_func

    ###################################### Sigma & Regulizers #####################################

    def eff_get_sigma(self, time_step, summation=False):
        dual_acc = 0  # this should be a VECTOR.
        dual_acc_pred = 0

        for k, v in self.duals[time_step].items():
            res_consts = np.pad(self.consts_preds_grads[time_step][k], (self.files * self.locations * self.caches, 0), 'constant')
            res_consts_preds = np.pad(self.consts_preds_grads[time_step][k], (self.files * self.locations * self.caches, 0),
                                      'constant')

            dual_acc += v * res_consts
            dual_acc_pred += v * res_consts_preds

            # dual_acc += v * self.consts[time_step][k][0]
            # dual_acc_pred += v * self.consts_preds[time_step][k][0]

        padded_get_func_grad = np.pad(self.get_func_grad(time_step),
                                      (0, self.files * self.caches), 'constant')

        padded_get_funcs_preds_grads = np.pad(self.get_funcs_preds_grads(time_step),
                                              (0, self.files * self.caches), 'constant')

        diff_norm = np.linalg.norm(padded_get_func_grad
                                   + dual_acc

                                   - (padded_get_funcs_preds_grads
                                      + dual_acc_pred)) ** 2
        # print("diff_norm of {} is {}".format(time_step, diff_norm))
        sigma_t = (np.sqrt(self.acc_diff_norm + diff_norm) - np.sqrt(self.acc_diff_norm)) * self.const_sigma
        self.sigmas[time_step] = sigma_t
        self.acc_diff_norm += diff_norm
        # print("Sigma {} is {}".format(time_step, sigma_t))
        return sigma_t

    ###################################### Steps #####################################
    def get_next_action(self, time_step):
        regs = 0
        funcs = 0
        consts = 0
        const_preds = 0
        z = self.z
        y = self.y
        x = self.x
        if time_step == 1:
            np.set_printoptions(suppress=True)

            regs = cp.sum_squares(x - 0.5)  # can i write thi s in terms of z, y

            # function predictions
            func_pred = self.funcs_preds[time_step][0] @ z + self.funcs_preds[time_step][1]

            # const pred
            for i, const in self.consts_preds[time_step].items():
                constraint_value = const[0] @ y + const[1]
                const_preds += self.duals[time_step][i] * constraint_value  # this is zero any way?

            objective = cp.Minimize(regs - func_pred + const_preds)
            prob = cp.Problem(objective, self.standard_constraints)
            result = prob.solve()

            self.actions[time_step] = x.value
            print("ACTION 1:, ", np.round(x.value,3))
            return x.value, z.value, y.value

        # t >= 2:
        ################################## CLOSED FORM + PROJ #######################################

        self.acc_func_grad += self.funcs[time_step - 1][0]
        res_cached_costs = np.pad(self.acc_func_grad, (0, self.files * self.caches), 'constant')
        res_funcs_preds = np.pad(self.funcs_preds[time_step][0], (0, self.files * self.caches), 'constant')

        sigma_t = self.eff_get_sigma(time_step - 1)
        x_t = self.actions[time_step - 1]
        self.accumelated_stxt += (sigma_t / 2 * x_t)  # sigma_t x_t
        self.accumelated_sigmas += sigma_t / 2

        const = self.consts_preds_grads[time_step][0]
        res_constraints_gradients = np.pad(const, (self.files * self.locations * self.caches, 0), 'constant')
        self.accumelated_lambdat_st += (self.duals[time_step][0] * res_constraints_gradients)

        np.set_printoptions(suppress=True)


        if self.accumelated_sigmas <=0:
            yy = ((+res_cached_costs + res_funcs_preds - self.accumelated_lambdat_st) / 2 + self.accumelated_stxt) / (
                1e-2)
        else:
            yy = ((+res_cached_costs + res_funcs_preds - self.accumelated_lambdat_st) / 2 + self.accumelated_stxt) / (
                self.accumelated_sigmas)

        # yy = ((+res_cached_costs + res_funcs_preds - self.accumelated_lambdat_st) / 2 + self.accumelated_stxt) / (
        #     self.accumelated_sigmas)

        ############################################################################################
        print(">>", yy)
        self.non_projected_sol_parameter.value = yy
        result = self.prob.solve()


        # objective = cp.Minimize(cp.sum_squares(x - yy))
        # prob = cp.Problem(objective, self.standard_constraints)
        # result = prob.solve()

        self.actions[time_step] = self.x.value
        return self.x.value, self.z.value, self.y.value


    def get_next_duals(self, time_step):
        a = 1 / (time_step ** self.beta)
        for i in range(self.consts_num):
            res_constraints_gradients = np.pad(self.consts[time_step - 1][i][0],
                                               (self.files * self.locations * self.caches, 0),'constant')
            constraint_value = res_constraints_gradients @ self.actions[time_step - 1] - self.consts[time_step - 1][i][1]  # (b_t is set positiv)
            self.acc_grad[i] += constraint_value
            self.duals[time_step][i] = max(0.0, a * self.acc_grad[i])  # this is for the outer projection
            print("new duals: ", self.duals[time_step])
        return self.duals[time_step]
