from scipy import io
import numpy as np
import matplotlib.pyplot as plt

class DataInterface():
    def __init__(self):
        loaded = io.loadmat('./yt_trace.mat')
        print(sorted(loaded.keys()))
        np_trace = loaded['trace0']

        # print('max', max(np_trace[0]))
        # print('min', min(np_trace[0]))
        (unique, counts) = np.unique(np_trace[0], return_counts=True)
        frequencies = np.asarray((unique, counts)).T
        # print(frequencies)
        # print('================')
        self.clipped = frequencies[frequencies[:,1]>=10]
        self.clipped = self.clipped[self.clipped[:, 1].argsort()[::-1]]
        self.denom = sum(self.clipped[:, 1])
        self.clipped[:, 0] = np.arange(self.clipped.shape[0])

        print(self.clipped.shape)
        # print(clipped)
        # print(clipped.shape)
        # print(sum(clipped[:,1]))

    def tr_sample(self):
        s = np.random.choice(self.clipped[:, 0], p=self.clipped[:, 1]/self.denom)
        return s

# di = DataInterface()
#
# samps=[]
# for i in range(10000):
#     s = di.tr_sample()
#     samps.append(s)
#
# print('done')
# samps=np.array(samps)
# plt.hist(samps, bins=np.arange(samps.min(), samps.max()+1), align='left')
# plt.show()