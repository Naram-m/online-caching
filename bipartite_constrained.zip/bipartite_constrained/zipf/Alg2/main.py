from agent_closed import Agent
from nature_caching import CN

from predictors import Predictor
import numpy as np
import time


T = 10000
num_constraints = 1

############################################################################
max_cache_size = 100
files = 1000
locations = 4
caches = 3
action_dim = files * locations * caches + files * caches
print("ACTION DIMENSION ", action_dim)
l = np.array([[1, 1, 0],
              [1, 1, 0],
              [0, 1, 1],
              [0, 1, 1]
              ])
utils = np.tile(np.array([1,2,100]), (1, files * locations))[0] # fixed utility per cache, for all n and i

CNNature = CN(num_constraints=1, utils=utils, l=l,  locations=locations, caches=caches, files = files, max_cache_size= max_cache_size)
zhs, yhs, true_grads, true_consts = CNNature.get_best_hindsight(T)
del[CNNature]
CNNature = CN(num_constraints=1, utils=utils, l=l,  locations=locations, caches=caches, files = files,  max_cache_size= max_cache_size)
###########################################################################

predictor = Predictor(dim=action_dim, type=1, true_grads=true_grads, true_consts=true_consts, num_constraints=num_constraints, eps=400, prob=0)
alg_instance = Agent(action_dim, num_constraints, l=l,  locations=locations, caches=caches, files = files, max_cache_size=max_cache_size)

f_best_hindsight = []
f_realized = []
regrets = []
violations=[]
cum_vals = np.array([0.0 for i in range(num_constraints)])  # num_constraints

START_TIME = time.time()
for t in range(1, T):
    print("\nIteration: ", t)

    # 1- get and set predictions
    func_pred = predictor.get_func_prediction_2(time_step=t)
    grad_pred = predictor.get_func_prediction_grad(time_step=t)
    alg_instance.set_funcs_preds(func_pred, time_step=t, linear=True)
    alg_instance.set_funcs_preds_grads(grad_pred, time_step=t, linear=True)

    const_pred = predictor.get_consts_prediction(time_step=t)
    const_grad_pred = predictor.get_consts_prediction_grad(time_step=t)
    alg_instance.set_consts_preds(const_pred, time_step=t, linear=True)
    alg_instance.set_consts_preds_grads(const_grad_pred, time_step=t, linear=True)

    # 2- get actions
    x, z, y = alg_instance.get_next_action(t)
    #print("Action: {}".format(np.round(x, 5)))

    # 3- announce cost function, and the constraint
    f = CNNature.generate_loss_function_wutils()
    print(">>",np.linalg.norm(f[0]-grad_pred))
    if np.linalg.norm(f[0] - true_grads[t]) > 0:
        print("Sequences not the same !")
        break
    alg_instance.set_func(f, time_step=t, linear=True)
    h = CNNature.generate_loss_function_gradient(linear=True)
    alg_instance.set_func_grad(h, time_step=t, linear=True)

    g = CNNature.generate_constraints()
    alg_instance.set_constraints(g, t, True)
    g_prime = CNNature.generate_constraints_gradients()
    alg_instance.set_constraints_grad(g_prime, t, linear=True)

    #print("For functions: \nTrue: {}, \n Pred:{}\n diff_norm_grad:{}".format(f, func_pred, np.linalg.norm(np.array(h) - np.array(grad_pred))))
    # print("For Constraints: \n True: {}, \n Pred:{}\n   diff_norm_grad:{}".format(g, const_pred, np.linalg.norm(g_prime[0] - const_grad_pred[0])))

    # 3a- For comparison
    f_best_hindsight.append(f[0] @ zhs + f[1])
    f_realized.append(f[0] @ z + f[1])
    # f_best_hindsight.append(f @ zhs)
    # f_realized.append(f @ z)
    regret = np.round(f_best_hindsight[-1] - f_realized[-1], 5)    # -1 multiplication is because of the maximization
    print("BHS: ", f_best_hindsight[-1])
    print("OL: ", f_realized[-1])
    print("Regret: ", regret)
    regrets.append(regret)

    #3b- Violations
    vals = []
    for const_idx, const in g.items():
        #pop_consts_gradients = np.tile(const[0], (1, files))[0]
        constraint_value = const[0] @ y + -1 * const[1]  # (b_t is set positiv)
        print("constraint_value: ", constraint_value)
        #print("y: ",np.round(y,3) )
        print("budget: ", np.round(const[1],3))
        vals.append(constraint_value)

    vals = np.array(vals)
    cum_vals = cum_vals + vals
    print("cum_vals=", cum_vals)
    proj_cum_vals = np.copy(cum_vals)
    proj_cum_vals[proj_cum_vals < 0] = 0


    #violations.append(np.linalg.norm(proj_cum_vals))
    violations.append(constraint_value)
    print("norm: ", np.linalg.norm(proj_cum_vals))


    # 3b- For predictor's records
    # 4- get transient functions and duals

    # 5- get the duals
    lambda_ = alg_instance.get_next_duals(t+1)      # at every time step, we set the lambda for the comming one to be ready for  x and z
    print("Duals of {}: {}".format(t+1, lambda_))

END_TIME = time.time()
print("Consumed time: ", END_TIME - START_TIME)
f_realized_cum = np.cumsum(np.array(f_realized))
f_best_hindsight_cum = np.cumsum(np.array(f_best_hindsight))
to_plot = np.round(np.round(f_best_hindsight_cum - f_realized_cum, 5), 5)
to_plot_2 = np.round(violations, 5)



# with open('results/con_n500_c50_rho0_t5k.npy', 'wb') as f:   #pp is for eps =0.1
#     np.save(f, f_best_hindsight)
#     np.save(f, f_realized)
#     np.save (f, violations)

with open('results_je/con_n1000_c100_rho0_t10k.npy', 'wb') as f:   #pp is for eps =0.1
    np.save(f, f_best_hindsight)
    np.save(f, f_realized)
    np.save (f, violations)
