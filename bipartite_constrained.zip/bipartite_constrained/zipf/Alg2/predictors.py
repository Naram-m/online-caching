import numpy as np
from collections import defaultdict

'''
methods here are of tow types. type one returns 0 (equivelent to no prediction), type 2 returns a predictions such that
the norm of the differene to the actual is epsiolon
'''


class Predictor():
    def __init__(self, type=0, dim=0, true_grads=None, true_consts=None, num_constraints=0, eps=0.1, seed=1, prob=0):
        np.random.seed(seed)
        self.eps = eps
        self.true_consts = true_consts
        self.num_constraints = num_constraints
        self.type = type
        self.dim = dim
        self.true_grads = true_grads
        self.grad = 0
        self.const = {}
        self.prob=prob

    def get_func_prediction_2(self, time_step=1):
        dummy_noise = np.random.rand(len(self.true_grads[time_step]))
        if np.random.random(1) <= self.prob:
            random_file = np.random.randint(low=0, high=1000)
            random_location = np.random.randint(low=0, high=4)
            pred_grad = self.true_grads[time_step]
        else:
            random_file = np.random.randint(low=0, high=1000)
            random_location = np.random.randint(low=0, high=4)
            pred_grad = np.zeros(len(self.true_grads[time_step]))
            start = random_file * random_location * 3 + random_location * 3 #(n \times (i \times j) + i \times *j) to go to specific n, i
            pred_grad [start : start + 3] = np.array([1, 2, 100])
        self.grad = pred_grad
        return [pred_grad, 0]

    def get_func_prediction(self, time_step=1):
        if self.type == 0:
            dummy_noise = np.random.rand(len(self.true_grads[time_step]))
            self.grad = np.zeros(len(self.true_grads[time_step]))
            return [np.zeros(len(self.true_grads[time_step])), 0]

        elif self.type == 1:
            noise = np.random.rand(len(self.true_grads[time_step]))
            noise = noise * self.eps / np.linalg.norm(noise, 2)
            # pred_grad = np.round(self.true_grads[time_step] + noise, 3)
            pred_grad = self.true_grads[time_step] + noise
            self.grad = pred_grad
            return [pred_grad, 0]

    # this should only be called after getting the function prediciton
    def get_func_prediction_grad(self, time_step=-1):
        return self.grad

    # always return correct prediction regardless of the grad.
    def get_consts_prediction(self, time_step=1):
        consts = defaultdict(list)
        noise = 0
        pred_consts = defaultdict()
        for i in range(self.num_constraints):
            pred_consts[i] = [self.true_consts[time_step][i][0] + noise,
                              0]  # Interestingly, the algorithm does not use prediction of the budget.
        self.const = pred_consts

        return self.const  # a defaultdict form const idx to a list l, l[0] cof vector, l[1] budget

    def get_consts_prediction_grad(self, time_step=-1):
        consts = defaultdict(list)
        temp_dict = {}
        for k, v in self.const.items():
            temp_dict[k] = v[0]
        return temp_dict
