import copy

import numpy as np
import cvxpy as cp
from collections import defaultdict
import matplotlib.pyplot as plt
from data_interface import DataInterface


# noinspection DuplicatedCode
class CN():
    def __init__(self, num_constraints, utils, l, seed=24, locations=4, caches=3, files=100, max_cache_size=10):
        self.max_cache_size=max_cache_size
        self.locations = locations
        self.caches = caches
        self.files = files
        self.utils = utils
        self.l = l

        np.random.seed(seed)
        self.num_constraints = num_constraints
        self.dim = (files * caches) + (files * locations * caches)
        self.grad = 0

        self.func_grads_history = {}
        self.consts_grads_history = {}
        self.call_count_adv = 0
        self.di=DataInterface()

    def generate_loss_function_wutils(self):  # this is generating r
        r = [np.zeros(self.locations) for i in range(self.files)]

        #for location in range(self.locations):
        location = np.random.choice(range(self.locations))
        # zipf
        # requested_id = np.random.zipf(1.5, 1)[0] - 1
        # while requested_id not in range(self.files):
        #     requested_id = np.random.zipf(1.5, 1)[0] - 1

        # actual trace
        requested_id = self.di.tr_sample()

        #print("location {} is requesting {}".format(location, requested_id))
        r[requested_id][location] = 1

        r = np.concatenate(r).ravel() # comment this before printing to help visualize each file
        extended_r = np.repeat(r, self.caches)
        coeff = self.utils * extended_r
        self.grad = coeff
        return [coeff, 0]  # recall that r is indexed with n and then i

    def generate_loss_function_gradient(self, linear=True):
        return self.grad


    # noinspection PyTypeChecker
    def get_best_hindsight(self, T, seed=24):
        np.random.seed(seed)
        y = cp.Variable(self.files * self.caches)                   # this is indexed as n,j
        z = cp.Variable(self.files * self.locations * self.caches)  # this is indexed as n, i, j
        constraints=[]

        # y set constraints
        y_consts_mat = []
        constraints.extend([y >= 0, y <= 1])
        for cache_idx in range(self.caches):
            const_coeff = np.zeros(self.files * self.caches)
            const_coeff[cache_idx::self.caches]=1
            '''below print for verification. this is the coeff vector of the constraints: 
            each vector (loop iteratoin) is for a cache the 1's corresponds to the elements that will be summed 
            from y_nj for that j'''
            y_consts_mat.append(copy.deepcopy(const_coeff))
        y_consts_mat = np.array([np.array(constraint) for constraint in y_consts_mat])
        constraints.extend([y_consts_mat @ y <= self.max_cache_size]) # we can later customize / replace C

        # z set constraints
        constraints.extend([z >= 0, z <= 1])
        z_consts_mat = []
        for ni in range(self.files*self.locations):
            start = ni*(self.caches)
            end = (ni+1)*(self.caches)
            const_coeff = np.zeros(self.files * self.locations * self.caches)
            const_coeff[start : end] = 1
            '''below print for verification. this is the coeff vector of the constraints: 
            each vector (loop iteratoin) is for a fixed n,i choices. The 1's corresponds to the elements that will be summed 
            from z_ni, which is all j's'''
            z_consts_mat.append(copy.deepcopy(const_coeff))
        z_consts_mat = np.array([np.array(constraint) for constraint in z_consts_mat])
        constraints.extend([z_consts_mat @ z <= 1]) # we can later customize C

        # problem constraints
        # can we find a better way? could not vectorize because could not populate (extend) y (a variable, noy np array)
        for n in range(self.files):
            for i in range(self.locations):
                for j in range(self.caches):
                    z_index = (self.locations * self.caches) * n + self.caches * i + j
                    y_index = self.caches * n + j
                    constraints.extend([z[z_index] <= y[y_index] * self.l[i, j]])

        exp = 0
        for i in range(1, T):
            dumm1 = np.random.rand(self.files * self.locations * self.caches)  # to simulate prediction sampling
            r = self.generate_loss_function_wutils()[0]
            self.func_grads_history[i] = r
            exp += r @ z

        objective = cp.Maximize(exp)
        prob = cp.Problem(objective, constraints)
        result = prob.solve()
        return z.value, y.value, self.func_grads_history, 0



'''
files = 10
max_cache_size =3
locations = 4
caches = 3

l = np.array([[1, 1, 0],
              [1, 1, 0],
              [0, 1, 1],
              [0, 1, 1]
              ])
utils = np.tile(np.array([1,2,100]), (1, files * locations))[0] # fixed utility per cache, for all n and i


a = CN(num_constraints=0, utils=utils, l=l,  locations=locations, caches=caches, files = files, max_cache_size=max_cache_size)
z, y,  requests, _ = a.get_best_hindsight(10000)
# plt.hist(requests, bins=np.arange(requests.min(), requests.max()+1))
# plt.show()

print(np.round(z, 3))
print("=============================")
print(np.split(np.round(y, 3), files))

a = CN(num_constraints=0, utils=utils, l=l,  locations=locations, caches=caches, files = files, max_cache_size=max_cache_size)

to_plot=[]
for t in range (500):
    r = a.generate_loss_function_wutils()[0]
    # extended_r = np.repeat(r, caches)
    # coeff = utils * extended_r
    fv = np.dot(r, z)
    to_plot.append(fv)

to_plot=np.array(to_plot)
plt.plot(to_plot)
print("--------------")
print(np.average(to_plot))
plt.show()
'''