import copy
import numpy as np
import cvxpy as cp

class OGDAgent():
    def __init__(self, l, locations, caches, files, max_cache_size):
        self.l = l
        self.files = files
        self.caches = caches
        self.locations = locations
        self.z_dim = self.files * self.locations * self.caches
        self.y_dim = self.files * self.caches
        self.z = cp.Variable(self.z_dim)
        self.y = cp.Variable(self.y_dim)
        self.x = cp.hstack([self.z, self.y])
        self.acc_grads = np.zeros(self.z_dim)

        self.max_cache_size = max_cache_size
        self.standard_constraints = []
        self.actions = []
        self.grads = []

        ####################################### Constraints ###################################
        # For y:
        self.standard_constraints.extend([self.y >= 0, self.y <= 1])
        y_consts_mat = []
        for cache_idx in range(self.caches):
            const_coeff = np.zeros(self.files * self.caches)
            const_coeff[cache_idx::self.caches] = 1
            y_consts_mat.append(copy.deepcopy(const_coeff))
        y_consts_mat = np.array([np.array(constraint) for constraint in y_consts_mat])
        self.standard_constraints.extend(
            [y_consts_mat @ self.y <= self.max_cache_size])  # we can later customize / replace C

        # For z:
        self.standard_constraints.extend([self.z >= 0, self.z <= 1])
        z_consts_mat = []
        for ni in range(self.files * self.locations):
            start = ni * (self.caches)
            end = (ni + 1) * (self.caches)
            const_coeff = np.zeros(self.files * self.locations * self.caches)
            const_coeff[start: end] = 1
            z_consts_mat.append(copy.deepcopy(const_coeff))
        z_consts_mat = np.array([np.array(constraint) for constraint in z_consts_mat])
        self.standard_constraints.extend([z_consts_mat @ self.z <= 1])  # we can later customize C

        # for the problem:
        self.fl = self.l.flatten()
        self.extended_fl = np.concatenate([self.fl for i in range(self.files)]).ravel()
        sl = []
        for p in range(self.files):
            start = self.caches * p
            end = self.caches * (p + 1)
            for pp in range(self.locations):
                sl.append(self.y[start:end])
        y_comp = cp.hstack(sl)
        self.standard_constraints.extend([self.z <= cp.multiply(y_comp, self.extended_fl)])
        #######################################################################################
        self.non_projected_sol_parameter = cp.Parameter(self.z_dim + self.y_dim)
        self.objective = cp.Minimize(cp.sum_squares(self.x - self.non_projected_sol_parameter))
        self.prob = cp.Problem(self.objective, self.standard_constraints)


    def step(self, grad):
        if not self.actions:
            yy = np.random.rand(self.z_dim + self.y_dim)
        else:
            ogd_step = np.sqrt(2 * self.caches * self.max_cache_size + 2) / (100 * np.sqrt(len(self.grads)+1))
            yy = self.actions[-1] + ogd_step * np.pad(self.grads[-1], (0, self.files * self.caches), 'constant')          # we are returning the reward

        # objective = cp.Minimize(cp.sum_squares(self.x - yy))
        # prob = cp.Problem(objective, self.standard_constraints)
        self.non_projected_sol_parameter.value = yy
        result = self.prob.solve(warm_start=True)
        self.grads.append(grad)
        self.actions.append(self.x.value)
        return self.x.value, self.z.value, self.y.value




