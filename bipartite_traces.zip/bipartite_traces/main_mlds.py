import numpy as np
from nature_mlds import CN
from predictor import Predictor
from BHS_agent import BHSAgent
from OGD_agent import OGDAgent
from OFTRL_agent import OFTRLAgent
import matplotlib.pyplot as plt

T = 10000
util_BHS = []
util_OGD = []
util_OFTRL_0 = []
util_OFTRL_07 = []

######################### Nature #####################
max_cache_size = 100
files = 1152
locations = 4
caches = 3
action_dim = files * locations * caches + files * caches
l = np.array([[1, 1, 0],
              [1, 1, 0],
              [0, 1, 1],
              [0, 1, 1]
              ])
utils = np.tile(np.array([1, 2, 100]), (1, files * locations))[0]  # fixed utility per cache, for all n and i
nature = CN(num_constraints=0, utils=utils, l=l, locations=locations, caches=caches, files=files,
            max_cache_size=max_cache_size)
predictor0 = Predictor(prob=0.0, l=l, locations=locations, caches=caches, files=files, max_cache_size=max_cache_size)
predictor07 = Predictor(prob=0.7, l=l, locations=locations, caches=caches, files=files, max_cache_size=max_cache_size)
######################################################

bhs_agent = BHSAgent(l=l, locations=locations, caches=caches, files=files, max_cache_size=max_cache_size)
ogd_agent = OGDAgent(l=l, locations=locations, caches=caches, files=files, max_cache_size=max_cache_size)
oftrl_agent_0 = OFTRLAgent(l=l, locations=locations, caches=caches, files=files, max_cache_size=max_cache_size,
                           predictor=predictor0)
oftrl_agent_07 = OFTRLAgent(l=l, locations=locations, caches=caches, files=files, max_cache_size=max_cache_size,
                            predictor=predictor07)
cum_c = np.zeros(files * caches * locations)

for t in range(1, T):
    if t % 10 == 0:
        print("\nStep: {}\n".format(t))
    c_t = nature.generate_cost()
    cum_c += c_t
    x_bhs, z_bhs, y_bhs = bhs_agent.step(c_t)
    x_ogd, z_ogd, y_ogd = ogd_agent.step(c_t)
    x_oftrl_0, z_oftrl_0, y_oftrl_0 = oftrl_agent_0.step(c_t)
    x_oftrl_07, z_oftrl_07, y_oftrl_07 = oftrl_agent_07.step(c_t)

    # x_co, z_co, y_co = co_agent.step(c_t)

    ## experts
    # x_oe, z_oe, y_oe = oe_agent.step(c_t)
    # x_re, z_re, y_re = re_agent.step(c_t)
    #########
    # x_gg, z_gg, y_gg = ogd_exp_agent.step(c_t)
    # z_gg = ogd_exp_agent.step(c_t)

    util_OGD.append(c_t @ z_ogd)
    util_BHS.append(cum_c @ z_bhs)
    util_OFTRL_0.append(c_t @ z_oftrl_0)
    util_OFTRL_07.append(c_t @ z_oftrl_07)


# below division is element wise
# util_BHS = np.cumsum(util_BHS) / np.arange(1, t + 1)
util_BHS = util_BHS / np.arange(1, t + 1)

util_OGD = np.cumsum(util_OGD) / np.arange(1, t + 1)
util_OFTRL_0 = np.cumsum(util_OFTRL_0) / np.arange(1, t + 1)
util_OFTRL_07 = np.cumsum(util_OFTRL_07) / np.arange(1, t + 1)



############################################### PLOTTING #########################################################
plt.figure(figsize=(6.5, 6.5))

plt.plot(np.arange(T - 1), util_BHS, color='Green', label="BHS", linewidth=3)
plt.plot(np.arange(T - 1), util_OGD, color='Black', label="OGD", linewidth=2.5, markevery=500, marker='x',
         markersize=12, markeredgecolor='Grey')

plt.plot(np.arange(T - 1), util_OFTRL_07, color='Blue', label=r"OBC, $\rho=0.7$", linewidth=2.5, markevery=1000,
         marker='d', markersize=12, markeredgecolor='Grey')
plt.plot(np.arange(T - 1), util_OFTRL_0, color='#0096FF', label=r"OBC, $\rho=0$", linewidth=2.5, markevery=1000,
         marker='v', markersize=12, markeredgecolor='Grey')

# plt.plot(np.arange(T-1), util_OGD_Experts_good, color='Orange', label=r"EC,  $\tau=10^{3}$", linewidth=2.5, markevery=1000, marker='s',  markersize=11, markeredgecolor='Grey')
# plt.plot(np.arange(T-1), util_OGD_Experts_bad, color='#FAD5A5', label=r"EC,  $\tau=1$", linewidth=2.5, markevery=1000, marker='p',  markersize=12, markeredgecolor='Grey')


plt.grid()
plt.legend(prop={'size': 12, 'weight': 'bold'})
plt.ylabel(r'$\mathbf{u_{1:T}\ /\ T}$', fontsize=16, weight='bold')
plt.xlabel(r'T', fontsize=16, weight='bold')
plt.yticks(fontsize=16, weight='bold')
# plt.ylim((0, 60))
plt.xticks(fontsize=16, weight='bold')

# plt.savefig("./random.pdf", bbox_inches = 'tight',pad_inches = 0)

plt.show()
################################################################################################################

with open('./mlds_results_je/util_OGD.npy', 'wb') as f:
    np.save(f, util_OGD)
with open('./mlds_results_je/util_BHS.npy', 'wb') as f:
    np.save(f, util_BHS)
with open('./mlds_results_je/util_OFTRL_0.npy', 'wb') as f:
    np.save(f, util_OFTRL_0)
with open('./mlds_results_je/util_OFTRL_07.npy', 'wb') as f:
    np.save(f, util_OFTRL_07)
