import pandas as pd
import numpy as np
from datetime import datetime

data = pd.read_csv("./ml-100k/u.data", delimiter="\t") # usecols=["movieId", "timestamp"]
data = data.iloc[:, [1, 3]]

id, counts = np.unique(data.iloc[:, 0].values, return_counts=True)
frequencies = np.asarray((id, counts)).T
clipped = frequencies[frequencies[:, 1] >= 10] #500 leads to 619, 10 leads to 9k
print("Total # of files: {}".format(len(clipped)))

data = data.loc[data.iloc[:, 0].isin(clipped[:, 0])]
data = data.sort_values(by=data.columns[1], ascending=True)
consec_id = -1
for original_id in clipped[:, 0]:
    consec_id += 1
    if consec_id % 100 == 0:
        print("#", end=" ")
    data.iloc[:, 0] = data.iloc[:, 0].replace(original_id, consec_id)

'''At this point, you know that # of files is 9k. However, not all of them might appear in
the trace. the trace is any 5k steps (or maybe make it 10k)
'''
# # pick a 5k interval (not all 9k files will appear)
# ################## Testing ######################
chunk = data.head(10000)
# chunk = data.iloc[start : end]
# the below is to know how many files, out of the 9k, is present in the selected 10k time steps.
id2, counts2 = np.unique(chunk.iloc[:, 0].values, return_counts=True)
print(len(id2))
#
# print("===")
# print(chunk.iloc[:, 0])

with open('./ml_trace_10k.npy', 'wb') as f:
    np.save(f, chunk.iloc[:, 0].values)

