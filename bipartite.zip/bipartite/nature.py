import copy

import numpy as np
import cvxpy as cp
from collections import defaultdict
import matplotlib.pyplot as plt

class CN():
    def __init__(self, num_constraints, utils, l, seed=24, locations=4, caches=3, files=100, max_cache_size=10):
        self.max_cache_size=max_cache_size
        self.locations = locations
        self.caches = caches
        self.files = files
        self.utils = utils
        self.l = l

        np.random.seed(seed)
        self.num_constraints = num_constraints
        self.dim = (files * caches) + (files * locations * caches)
        self.grad = 0

        self.func_grads_history = {}
        self.consts_grads_history = {}
        self.call_count_adv = 0

        self.min = np.uint64(1)
        self.max = np.uint64(self.files)

    def generate_cost(self):  # this is generating r
        r = [np.zeros(self.locations) for i in range(self.files)]
        location = np.random.choice(range(self.locations))
        requested_id = self.Zipf(1.1, self.min, self.max) - 1
        requested_id = int(requested_id)
        # requested_id = np.random.zipf(1.1, 1)[0] - 1
        # while requested_id not in range(self.files):
        #     requested_id = np.random.zipf(1.2, 1)[0] - 1  # to make file ids start from 0
        r[requested_id][location] = 1

        r = np.concatenate(r).ravel() # comment this before printing to help visualize each file
        extended_r = np.repeat(r, self.caches)
        coeff = self.utils * extended_r
        self.grad = coeff
        return coeff

    def Zipf(self, a: np.float64, min: np.uint64, max: np.uint64, size=None):
        """
        Generate Zipf-like random variables,
        but in inclusive [min...max] interval
        """
        if min == 0:
            raise ZeroDivisionError("")

        v = np.arange(min, max + 1)  # values to sample
        p = 1.0 / np.power(v, a)  # probabilities
        p /= np.sum(p)  # normalized

        return np.random.choice(v, size=size, replace=True, p=p)
