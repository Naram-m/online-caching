import numpy as np


class Predictor():

    def __init__(self, prob=0, l=-1, locations=-1, caches=-1, files=-1, max_cache_size=-1):
        self.prob = prob
        self.max_cache_size = max_cache_size
        self.files = files
        self.locations = locations
        self.caches = caches
        self.action_dim = files * locations * caches + files * caches
        self.l = np.array([[1, 1, 0],
                      [1, 1, 0],
                      [0, 1, 1],
                      [0, 1, 1]
                      ])
        self.utils = np.tile(np.array([1, 2, 100]), (1, files * locations))[0]  # fixed utility per cache, for all n and i

    def get_prediction(self, grad):  # grad is the true grad
        if np.random.random(1) <= self.prob:
            pred = grad
        else:
            r = [np.zeros(self.locations) for i in range(self.files)]
            location = np.random.choice(range(self.locations))
            requested_id = np.random.randint(low=0, high=1000)

            r[requested_id][location] = 1
            r = np.concatenate(r).ravel()  # comment this before printing to help visualize each file
            extended_r = np.repeat(r, self.caches)
            coeff = self.utils * extended_r
            pred = coeff
        return pred
