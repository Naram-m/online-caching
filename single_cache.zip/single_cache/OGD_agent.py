import numpy as np
import cvxpy as cp

class OGDAgent():
    def __init__(self, l, locations, caches, files, max_cache_size):
        self.l = l
        self.files = files
        self.caches = caches
        self.locations = locations
        self.y_dim = self.files * self.caches
        self.y = cp.Variable(self.y_dim)
        self.R = np.sqrt(2 * max_cache_size)  # only here from Hazan it is the diameter D. Otherwise, an upper bound on the l2 norm of x

        self.max_cache_size = max_cache_size
        self.standard_constraints = []
        self.actions = []
        self.grads = []

        # For y:
        self.standard_constraints.extend([self.y >= 0, self.y <= 1])
        self.standard_constraints.extend([cp.sum(self.y) <= self.max_cache_size])

        self.non_projected_sol_parameter = cp.Parameter(self.y_dim)
        self.objective = cp.Minimize(cp.sum_squares(self.y - self.non_projected_sol_parameter))
        self.prob = cp.Problem(self.objective, self.standard_constraints)

    def step(self, grad):
        if not self.actions:
            yy = np.random.rand(self.y_dim)
        else:
            ogd_step = self.R / (1 * np.sqrt(len(self.grads))) # this is \frac{D}{G\sqrt{t}}; D=\sqsrt{2C}, G=1
            yy = self.actions[-1] + ogd_step * self.grads[-1]          # we are returning the reward

        self.non_projected_sol_parameter.value = yy
        result = self.prob.solve(warm_start=True)
        self.grads.append(grad)
        self.actions.append(self.y.value)
        return self.y.value





