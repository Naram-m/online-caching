import numpy as np

from BHS_agent import BHSAgent
from OGD_agent import OGDAgent
from oftrl_agent import OFTRLAgent
from nature_ytds import CN


T = 10000 # exactly the length of the trace
util_BHS = []
util_OGD = []
util_OFTRL_0 = []
util_OFTRL_07 = []

######################### Nature #####################
max_cache_size = 100
files = 10000
locations = 1
caches = 1
action_dim = files * locations * caches + files * caches
l = np.array([[1]])
utils = np.tile(np.array([1]), (1, files * locations))[0] # fixed utility per cache, for all n and i
nature = CN(num_constraints=0, utils=utils, l=l,  locations=locations, caches=caches, files=files, max_cache_size=max_cache_size)
cum_c = np.zeros(files)

######################### Agents #####################
bhs_agent = BHSAgent(l=l, locations=locations, caches=caches, files=files, max_cache_size=max_cache_size)
ogd_agent = OGDAgent(l=l, locations=locations, caches=caches, files=files, max_cache_size=max_cache_size)
oftrl_agent_rho0 = OFTRLAgent(l=l, locations=locations, caches=caches, files=files, max_cache_size=max_cache_size, rho=0)
oftrl_agent_rho07 = OFTRLAgent(l=l, locations=locations, caches=caches, files=files, max_cache_size=max_cache_size, rho=0.7)


################### Interaction loop ###############
# for t in range(1, T):
for t in range(1, T+1): # last value that t takes is T. Also, below we will have t c_t's accumulated at each iteration
    if t % 10 == 0:
        print("\nStep: {}\n".format(t))
    c_t = nature.generate_cost()
    cum_c += c_t
    y_bhs = bhs_agent.step(c_t)
    y_ogd = ogd_agent.step(c_t)
    y_oftrl_0 = oftrl_agent_rho0.step(c_t)
    y_oftrl_07 = oftrl_agent_rho07.step(c_t)


    util_BHS.append(cum_c @ y_bhs)
    util_OGD.append(c_t @ y_ogd)
    util_OFTRL_0.append(c_t @ y_oftrl_0)
    util_OFTRL_07.append(c_t @ y_oftrl_07)



################### Utils calculation ###############
# below division is element wise
# util_BHS = np.cumsum(util_BHS) / np.arange(1, t + 1)

####################################################

util_BHS = util_BHS[101:]
util_OGD = util_OGD[101:]
util_OFTRL_0 = util_OFTRL_0[101:]
util_OFTRL_07 = util_OFTRL_07[101:]
####################################################
# util_BHS = util_BHS / np.arange(1, t)
# util_OGD = np.cumsum(util_OGD) / np.arange(1, t)
util_BHS = util_BHS / np.arange(101, t) # here, t will be T
util_OGD = np.cumsum(util_OGD) / np.arange(101, t)
util_OFTRL_0 = np.cumsum(util_OFTRL_0) / np.arange(101, t)
util_OFTRL_07 = np.cumsum(util_OFTRL_07) / np.arange(101, t)


with open('./plots/ytds/BHS.npy', 'wb') as f:
    np.save(f, util_BHS)

with open('./plots/ytds/OGD.npy', 'wb') as f:
    np.save(f, util_OGD)

with open('./plots/ytds/OFTRL_0.npy', 'wb') as f:
    np.save(f, util_OFTRL_0)

with open('./plots/ytds/OFTRL_07.npy', 'wb') as f:
    np.save(f, util_OFTRL_07)