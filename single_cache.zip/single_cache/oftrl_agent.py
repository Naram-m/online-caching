import copy
import numpy as np
import cvxpy as cp


class OFTRLAgent():
    def __init__(self, l, locations, caches, files, max_cache_size, is_per=False, per=-1, rho='a'):
        self.rho=rho
        self.ind = -1
        self.is_per = is_per
        self.per = per

        self.l = l
        self.files = files
        self.caches = caches
        self.locations = locations
        self.y_dim = self.files * self.caches
        self.y = cp.Variable(self.y_dim)
        self.acc_grads = np.zeros(self.y_dim)


        self.max_cache_size = max_cache_size
        self.standard_constraints = []
        self.actions = []
        self.grads = []
        self.acc_sigma = 0
        self.acc_sigma_action = 0
        self.sigmas = []
        ##############
        self.etas = []
        self.acc_grad_square = 0

        self.R = np.sqrt(max_cache_size)  # an upper bound on the l2 norm of x (20 Jan: not diameter?)



        ####################################### Constraints ###################################
        # For y:
        self.standard_constraints.extend([self.y >= 0, self.y <= 1])
        self.standard_constraints.extend([cp.sum(self.y)<=self.max_cache_size])


        #######################################################################################

        self.non_projected_sol_parameter = cp.Parameter(self.y_dim)

        self.objective = cp.Minimize(cp.sum_squares(self.y - self.non_projected_sol_parameter))

        self.prob = cp.Problem(self.objective, self.standard_constraints)

    def calc_sigma(self, pred):
        if not self.sigmas:  # no grads yet
            self.etas.append(1)  # for t=0
            self.sigmas.append(1 / self.etas[-1])  # from McMahan \sigma_0  = 1 / \eta_0
        else:
            self.acc_grad_square += np.linalg.norm(self.grads[-1] - pred, 2) ** 2
            self.etas.append(
                np.sqrt(2) * self.R / np.sqrt(self.acc_grad_square))  # this will be the second eta, after 0
            self.sigmas.append(1 / self.etas[-1] - 1 / self.etas[-2])

    def step(self, grad):
        if np.random.rand() <= self.rho:
            pred = grad
        else:
            pred = np.zeros(len(grad))
            pred[np.random.randint(0, len(grad))] = 1

        if not self.actions:  # first action, minimize r_0, returning 0 because it assumed to be ||x||
            # yy = np.random.rand(self.z_dim + self.y_dim)
            yy = np.random.rand(self.y_dim)

        else:
            # 1- calculating x, all involved params should be ready.
            if self.acc_sigma > 0:
                yy = (self.acc_sigma_action + (self.acc_grads + pred)) / self.acc_sigma

            else:   # below is still not a parameter ..
                a = self.acc_grads + pred
                objective = cp.Maximize(a @ self.y)
                prob = cp.Problem(objective, self.standard_constraints)
                result = prob.solve(warm_start=True)

        # Projection
        if self.acc_sigma > 0 or not self.actions:
            self.non_projected_sol_parameter.value = yy
            result = self.prob.solve(warm_start=True)
        self.actions.append(self.y.value)


        # 2 - preparing params for next round
        self.grads.append(grad)
        self.acc_grads += self.grads[-1]
        self.calc_sigma(pred)
        self.acc_sigma += self.sigmas[-1]
        self.acc_sigma_action += self.sigmas[-1] * self.actions[-1]

        return self.y.value

