import numpy as np
from yt_data_interface import DataInterface

class CN():
    def __init__(self, num_constraints, utils, l, seed=24, locations=4, caches=3, files=100, max_cache_size=10):
        self.max_cache_size=max_cache_size
        self.locations = locations
        self.caches = caches
        self.files = files
        self.utils = utils
        self.l = l

        np.random.seed(seed)
        self.num_constraints = num_constraints
        self.dim = (files * caches) + (files * locations * caches)
        self.grad = 0

        self.func_grads_history = {}
        self.consts_grads_history = {}
        self.call_count_adv = 0
        self.ind = 0

        self.min = np.uint64(1)
        self.max = np.uint64(self.files)
        self.di = DataInterface()


    def generate_cost(self):  # this is generating r
        r = [np.zeros(self.locations) for i in range(self.files)]
        #for location in range(self.locations):
        location = np.random.choice(range(self.locations))
        # requested_id = self.Zipf(1.2, self.min, self.max) - 1
        # requested_id = int(requested_id)

        requested_id = self.di.tr_sample()


        #print("location {} is requesting {}".format(location, requested_id))

        self.ind += 1
        r[requested_id][location] = 1

        r = np.concatenate(r).ravel() # comment this before printing to help visualize each file
        extended_r = np.repeat(r, self.caches)
        coeff = self.utils * extended_r
        self.grad = coeff
        return coeff

    def Zipf(self, a: np.float64, min: np.uint64, max: np.uint64, size=None):
        """
        Generate Zipf-like random variables,
        but in inclusive [min...max] interval
        """
        if min == 0:
            raise ZeroDivisionError("")

        v = np.arange(min, max + 1)  # values to sample
        p = 1.0 / np.power(v, a)  # probabilities
        p /= np.sum(p)  # normalized

        return np.random.choice(v, size=size, replace=True, p=p)
