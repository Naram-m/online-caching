import numpy as np
import cvxpy as cp

class BHSAgent():
    def __init__(self, l, locations, caches, files, max_cache_size):
        self.l = l
        self.files = files
        self.caches = caches
        self.locations = locations
        self.y_dim = self.files * self.caches
        self.y = cp.Variable(self.y_dim)
        self.acc_grads = np.zeros(self.y_dim)

        self.max_cache_size = max_cache_size
        self.standard_constraints = []

        # For y:
        self.standard_constraints.extend([self.y >= 0, self.y <= 1])
        self.standard_constraints.extend([cp.sum(self.y) <= self.max_cache_size])

        # parameter
        self.acc_grads_parameter = cp.Parameter(self.y_dim, nonneg=True)

        # Problem setup
        self.objective = cp.Maximize(self.acc_grads_parameter @ self.y)
        self.prob = cp.Problem(self.objective, self.standard_constraints)

    def step(self, grad):
        self.acc_grads += grad
        self.acc_grads_parameter.value = self.acc_grads
        result = self.prob.solve(warm_start=True)
        return self.y.value

